package com.example.malingin_mvvm.model

data class User(
    val name: String
)
