package com.example.malingin_mvvm.viewmodel

import androidx.lifecycle.ViewModel
import com.example.malingin_mvvm.model.User

class UserViewModel : ViewModel() {

    val users = listOf(
        User("Alice"),
        User("Bob"),
        User("Charlie"),
        User("David")
    )
}
